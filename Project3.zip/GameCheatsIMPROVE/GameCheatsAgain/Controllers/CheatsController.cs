﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GameCheatsAgain.Models;

namespace GameCheatsAgain.Controllers
{
    public class CheatsController : Controller
    {
        private readonly GameCheatsContext _context;

        public CheatsController(GameCheatsContext context)
        {
            _context = context;
        }

        // GET: Cheats
        [HttpGet]
        public async Task<IActionResult> Index(string? searchBox, string[]? selectedPlatforms)
        {
            IQueryable<Cheats> gameCheatsContext = _context.Cheats.Include(c => c.UsernameNavigation);
            if (!string.IsNullOrEmpty(searchBox))
            {
                gameCheatsContext = gameCheatsContext.Where(c => c.Input.Contains(searchBox));
            }

            // check if optional variable has value, then check value
            if(selectedPlatforms.Count() > 0)
            {
                gameCheatsContext = gameCheatsContext.Where(c => selectedPlatforms.Contains(c.GamePlatform.ToLower()));
            }

            // Populate table with platforms and pass platform list to Viewdata for later

            ViewBag.SelectedPlatforms = selectedPlatforms.Count();


            return View(await gameCheatsContext.ToListAsync());
        }

        // GET: Cheats/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cheats = await _context.Cheats
                .Include(c => c.UsernameNavigation)
                .FirstOrDefaultAsync(m => m.CheatId == id);
            if (cheats == null)
            {
                return NotFound();
            }

            return View(cheats);
        }

        // GET: Cheats/Create
        public IActionResult Create()
        {
            ViewData["Username"] = new SelectList(_context.Users, "Username", "Username");
            return View();
        }

        // POST: Cheats/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CheatId,Game,GamePlatform,CheatTitle,Input,Username")] Cheats cheats)
        {
            if (ModelState.IsValid)
            {
                _context.Add(cheats);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Username"] = new SelectList(_context.Users, "Username", "Username", cheats.Username);
            return View(cheats);
        }

        // GET: Cheats/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cheats = await _context.Cheats.FindAsync(id);
            if (cheats == null)
            {
                return NotFound();
            }
            ViewData["Username"] = new SelectList(_context.Users, "Username", "Username", cheats.Username);
            return View(cheats);
        }

        // POST: Cheats/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CheatId,Game,GamePlatform,CheatTitle,Input,Username")] Cheats cheats)
        {
            if (id != cheats.CheatId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cheats);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CheatsExists(cheats.CheatId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Username"] = new SelectList(_context.Users, "Username", "Username", cheats.Username);
            return View(cheats);
        }

        // GET: Cheats/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cheats = await _context.Cheats
                .Include(c => c.UsernameNavigation)
                .FirstOrDefaultAsync(m => m.CheatId == id);
            if (cheats == null)
            {
                return NotFound();
            }

            return View(cheats);
        }

        // POST: Cheats/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cheats = await _context.Cheats.FindAsync(id);
            _context.Cheats.Remove(cheats);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CheatsExists(int id)
        {
            return _context.Cheats.Any(e => e.CheatId == id);
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GameCheatsAgain.Models
{
    public partial class HenryGUIContext : DbContext
    {
        public HenryGUIContext()
        {
        }

        public HenryGUIContext(DbContextOptions<HenryGUIContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Author> Author { get; set; }
        public virtual DbSet<Book> Book { get; set; }
        public virtual DbSet<Branch> Branch { get; set; }
        public virtual DbSet<Copy> Copy { get; set; }
        public virtual DbSet<Publisher> Publisher { get; set; }
        public virtual DbSet<Wrote> Wrote { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=tcp:guijakereccelle.database.windows.net,1433;Database=HenryGUI;User ID=jcreccelle;Password=Trooperm@x121399;Trusted_Connection=False;Encrypt=True;");
            }
        } 

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Author>(entity =>
            {
                entity.HasKey(e => e.AuthorNum)
                    .HasName("PK__Author__7E6BD29CADEA49CE");

                entity.Property(e => e.AuthorNum).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.AuthorFirst)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AuthorLast)
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Book>(entity =>
            {
                entity.HasKey(e => e.BookCode)
                    .HasName("PK__Book__0A5FFCC68BF11BB6");

                entity.Property(e => e.BookCode)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Paperback)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PublisherCode)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Title)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Type)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Branch>(entity =>
            {
                entity.HasKey(e => e.BranchNum)
                    .HasName("PK__Branch__0E8D21C5ECD5A4A8");

                entity.Property(e => e.BranchNum).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.BranchLocation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BranchName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Copy>(entity =>
            {
                entity.HasKey(e => new { e.BookCode, e.BranchNum, e.CopyNum })
                    .HasName("PK__Copy__3462780C914B63CA");

                entity.Property(e => e.BookCode)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BranchNum).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.CopyNum).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.Price).HasColumnType("decimal(8, 2)");

                entity.Property(e => e.Quality)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Publisher>(entity =>
            {
                entity.HasKey(e => e.PublisherCode)
                    .HasName("PK__Publishe__DFB88E28B6152AC3");

                entity.Property(e => e.PublisherCode)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.City)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PublisherName)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Wrote>(entity =>
            {
                entity.HasKey(e => new { e.BookCode, e.AuthorNum })
                    .HasName("PK__Wrote__DDB941EF041B57BC");

                entity.Property(e => e.BookCode)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AuthorNum).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.Sequence).HasColumnType("decimal(2, 0)");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

﻿using System;
using System.Collections.Generic;

namespace GameCheatsAgain.Models
{
    public partial class Users
    {
        public Users()
        {
            Cheats = new HashSet<Cheats>();
        }

        public string Username { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Email { get; set; }
        public string Pass { get; set; }
        public string ConfirmPass { get; set; }

        public virtual ICollection<Cheats> Cheats { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace GameCheatsAgain.Models
{
    public partial class Publisher
    {
        public string PublisherCode { get; set; }
        public string PublisherName { get; set; }
        public string City { get; set; }
    }
}

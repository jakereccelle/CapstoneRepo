﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GameCheatsAgain.Models
{
    public partial class GameCheatsContext : DbContext
    {
        public GameCheatsContext()
        {
        }

        public GameCheatsContext(DbContextOptions<GameCheatsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cheats> Cheats { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        /*protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=QUINN-3\\DATABASESQL;Database=GameCheats;Trusted_Connection=True;");
            }
        }*/

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Cheats>(entity =>
            {
                entity.HasKey(e => e.CheatId)
                    .HasName("PK__Cheats__B6F3BC706A06A443");

                entity.Property(e => e.CheatId).HasColumnName("cheatID");

                entity.Property(e => e.CheatTitle)
                    .HasColumnName("cheatTitle")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Game)
                    .HasColumnName("game")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.GamePlatform)
                    .HasColumnName("gamePlatform")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Input)
                    .HasColumnName("input")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.Cheats)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK__Cheats__username__3B75D760");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.Username)
                    .HasName("PK__Users__F3DBC573DC8C1DD3");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.Property(e => e.ConfirmPass)
                    .HasColumnName("confirmPass")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FName)
                    .HasColumnName("fName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LName)
                    .HasColumnName("lName")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Pass)
                    .HasColumnName("pass")
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

﻿using System;
using System.Collections.Generic;

namespace GameCheatsAgain.Models
{
    public partial class Cheats
    {
        public int CheatId { get; set; }
        public string Game { get; set; }
        public string GamePlatform { get; set; }
        public string CheatTitle { get; set; }
        public string Input { get; set; }
        public string Username { get; set; }

        public virtual Users UsernameNavigation { get; set; }
    }
}
